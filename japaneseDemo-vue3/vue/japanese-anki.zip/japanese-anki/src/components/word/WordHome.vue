<template>
    <RouterLink to="/word/list">展示所有单词</RouterLink>
</template>

<script lang="ts" setup>
    import { RouterLink } from 'vue-router';
</script>

<style scoped>

</style>