# Japanese_Anki
独立出一个Japanese Anki背词项目，有望做成一个基于Vue3+Springboot的独立项目。
