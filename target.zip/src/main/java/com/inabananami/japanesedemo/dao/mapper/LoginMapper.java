package com.inabananami.japanesedemo.dao.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LoginMapper {

}